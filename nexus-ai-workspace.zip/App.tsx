
import React, { useState, useCallback } from 'react';
import { 
  BookText, 
  MessageSquareCode, 
  Terminal, 
  Palette, 
  Video, 
  Settings, 
  Layout, 
  Search,
  Maximize2
} from 'lucide-react';
import FloatingWindow from './components/FloatingWindow';
import Notebook from './components/Notebook';
import AIChat from './components/AIChat';
import CodeCompiler from './components/CodeCompiler';
import Whiteboard from './components/Whiteboard';
import ScreenRecorder from './components/ScreenRecorder';
import { WindowState, WindowType } from './types';

const App: React.FC = () => {
  const [windows, setWindows] = useState<WindowState[]>([
    { id: '1', type: 'notebook', title: 'Smart Notebook', isOpen: true, isMinimized: false, zIndex: 10, position: { x: 50, y: 50 }, size: { width: 800, height: 600 } },
    { id: '2', type: 'chat', title: 'Nexus AI Assistant', isOpen: true, isMinimized: false, zIndex: 20, position: { x: 900, y: 50 }, size: { width: 400, height: 600 } },
  ]);
  const [maxZIndex, setMaxZIndex] = useState(21);

  const toggleWindow = (type: WindowType, title: string) => {
    const existing = windows.find(w => w.type === type);
    if (existing) {
      if (existing.isOpen && !existing.isMinimized) {
        // Bring to front
        focusWindow(existing.id);
      } else {
        // Re-open or de-minimize
        setWindows(prev => prev.map(w => w.id === existing.id ? { ...w, isOpen: true, isMinimized: false, zIndex: maxZIndex + 1 } : w));
        setMaxZIndex(prev => prev + 1);
      }
    } else {
      const newWin: WindowState = {
        id: Date.now().toString(),
        type,
        title,
        isOpen: true,
        isMinimized: false,
        zIndex: maxZIndex + 1,
        position: { x: 100 + (windows.length * 30), y: 100 + (windows.length * 30) },
        size: { width: 600, height: 450 }
      };
      setWindows(prev => [...prev, newWin]);
      setMaxZIndex(prev => prev + 1);
    }
  };

  const focusWindow = (id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, zIndex: maxZIndex + 1 } : w));
    setMaxZIndex(prev => prev + 1);
  };

  const closeWindow = (id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isOpen: false } : w));
  };

  const minimizeWindow = (id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isMinimized: true } : w));
  };

  const renderWindowContent = (win: WindowState) => {
    switch (win.type) {
      case 'notebook': return <Notebook />;
      case 'chat': return <AIChat />;
      case 'compiler': return <CodeCompiler />;
      case 'whiteboard': return <Whiteboard />;
      case 'recorder': return <ScreenRecorder />;
      default: return null;
    }
  };

  const getIcon = (type: WindowType) => {
    switch (type) {
      case 'notebook': return <BookText size={18} />;
      case 'chat': return <MessageSquareCode size={18} />;
      case 'compiler': return <Terminal size={18} />;
      case 'whiteboard': return <Palette size={18} />;
      case 'recorder': return <Video size={18} />;
      default: return <Layout size={18} />;
    }
  };

  return (
    <div className="h-screen w-screen bg-slate-950 overflow-hidden relative select-none">
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
        <div className="absolute top-0 -left-1/4 w-1/2 h-1/2 bg-blue-600 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 -right-1/4 w-1/2 h-1/2 bg-indigo-600 rounded-full blur-[150px]" />
      </div>

      {/* Main Dock / Sidebar */}
      <div className="absolute left-6 top-1/2 -translate-y-1/2 z-[100] flex flex-col gap-4 p-3 bg-slate-900/60 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/20 mb-4">
          <Sparkles size={20} />
        </div>
        
        <DockItem icon={<BookText />} label="Notebook" active={windows.find(w => w.type === 'notebook')?.isOpen} onClick={() => toggleWindow('notebook', 'Smart Notebook')} />
        <DockItem icon={<MessageSquareCode />} label="AI Assistant" active={windows.find(w => w.type === 'chat')?.isOpen} onClick={() => toggleWindow('chat', 'Nexus AI Assistant')} />
        <DockItem icon={<Terminal />} label="Code Lab" active={windows.find(w => w.type === 'compiler')?.isOpen} onClick={() => toggleWindow('compiler', 'Nexus Code Lab')} />
        <DockItem icon={<Palette />} label="Whiteboard" active={windows.find(w => w.type === 'whiteboard')?.isOpen} onClick={() => toggleWindow('whiteboard', 'Creative Board')} />
        <DockItem icon={<Video />} label="Record" active={windows.find(w => w.type === 'recorder')?.isOpen} onClick={() => toggleWindow('recorder', 'Screen Recorder')} />
        
        <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col gap-4">
          <DockItem icon={<Settings />} label="Settings" onClick={() => {}} />
        </div>
      </div>

      {/* Workspace Area */}
      <main className="absolute inset-0 z-10 p-4">
        {windows.map(win => (
          !win.isMinimized && win.isOpen && (
            <FloatingWindow
              key={win.id}
              title={win.title}
              icon={getIcon(win.type)}
              isOpen={win.isOpen}
              onClose={() => closeWindow(win.id)}
              onMinimize={() => minimizeWindow(win.id)}
              zIndex={win.zIndex}
              onFocus={() => focusWindow(win.id)}
              initialPos={win.position}
              initialSize={win.size}
            >
              {renderWindowContent(win)}
            </FloatingWindow>
          )
        ))}
      </main>

      {/* Taskbar / Active Windows */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-2 p-2 bg-slate-900/40 backdrop-blur-md border border-slate-700/30 rounded-full shadow-lg">
        {windows.filter(w => w.isOpen).map(win => (
          <button
            key={win.id}
            onClick={() => {
              if (win.isMinimized) {
                setWindows(prev => prev.map(w => w.id === win.id ? { ...w, isMinimized: false, zIndex: maxZIndex + 1 } : w));
                setMaxZIndex(prev => prev + 1);
              } else {
                focusWindow(win.id);
              }
            }}
            className={`px-3 py-1.5 rounded-full flex items-center gap-2 transition-all ${
              win.isMinimized ? 'opacity-40 grayscale' : 'bg-slate-800/80 text-white'
            } hover:bg-slate-700`}
          >
            <span className="text-blue-400">{getIcon(win.type)}</span>
            <span className="text-xs font-medium">{win.title}</span>
          </button>
        ))}
      </div>

      {/* Branding */}
      <div className="absolute top-6 right-8 z-[100] flex items-center gap-4 text-slate-400">
        <div className="flex flex-col items-end">
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-500">Workspace</span>
          <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-400">NEXUS AI</span>
        </div>
      </div>
    </div>
  );
};

interface DockItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const DockItem: React.FC<DockItemProps> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`group relative p-3 rounded-xl transition-all duration-300 ${
      active ? 'bg-blue-600/10 text-blue-400 shadow-inner' : 'text-slate-500 hover:bg-slate-800 hover:text-slate-200'
    }`}
    title={label}
  >
    {icon}
    {active && <div className="absolute left-0 top-3 bottom-3 w-1 bg-blue-500 rounded-full" />}
    <span className="absolute left-full ml-4 px-2 py-1 bg-slate-800 text-white text-[10px] rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-[1000] border border-slate-700">
      {label}
    </span>
  </button>
);

const Sparkles: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="currentColor" />
    <path d="M19 3L20 6L23 7L20 8L19 11L18 8L15 7L18 6L19 3Z" fill="currentColor" className="opacity-60" />
    <path d="M5 16L6 19L9 20L6 21L5 24L4 21L1 20L4 19L5 16Z" fill="currentColor" className="opacity-60" />
  </svg>
);

export default App;
