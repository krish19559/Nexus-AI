
import React, { useState, useRef, useEffect, ReactNode } from 'react';
import { X, Minus, Square, Maximize2, Move } from 'lucide-react';

interface FloatingWindowProps {
  title: string;
  icon: ReactNode;
  children: ReactNode;
  isOpen: boolean;
  onClose: () => void;
  onMinimize: () => void;
  zIndex: number;
  onFocus: () => void;
  initialPos?: { x: number; y: number };
  initialSize?: { width: number; height: number };
}

const FloatingWindow: React.FC<FloatingWindowProps> = ({
  title,
  icon,
  children,
  isOpen,
  onClose,
  onMinimize,
  zIndex,
  onFocus,
  initialPos = { x: 100, y: 100 },
  initialSize = { width: 600, height: 450 },
}) => {
  const [pos, setPos] = useState(initialPos);
  const [size, setSize] = useState(initialSize);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const windowRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handleMouseDown = (e: React.MouseEvent) => {
    onFocus();
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - pos.x,
      y: e.clientY - pos.y,
    });
  };

  const handleResizeMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsResizing(true);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPos({
          x: e.clientX - dragOffset.x,
          y: e.clientY - dragOffset.y,
        });
      }
      if (isResizing) {
        setSize({
          width: Math.max(300, e.clientX - pos.x),
          height: Math.max(200, e.clientY - pos.y),
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, dragOffset, pos]);

  return (
    <div
      ref={windowRef}
      className="absolute bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col transition-shadow duration-300"
      style={{
        left: pos.x,
        top: pos.y,
        width: size.width,
        height: size.height,
        zIndex: zIndex,
        boxShadow: zIndex > 50 ? '0 25px 50px -12px rgba(0, 0, 0, 0.5)' : 'none',
      }}
      onClick={onFocus}
    >
      {/* Header */}
      <div
        className="h-10 bg-slate-800 flex items-center justify-between px-3 cursor-grab active:cursor-grabbing select-none border-b border-slate-700"
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center gap-2 text-slate-200">
          <span className="text-blue-400">{icon}</span>
          <span className="text-sm font-semibold tracking-wide truncate">{title}</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={(e) => { e.stopPropagation(); onMinimize(); }} className="p-1.5 hover:bg-slate-700 rounded-md transition-colors text-slate-400">
            <Minus size={14} />
          </button>
          <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="p-1.5 hover:bg-red-500 hover:text-white rounded-md transition-colors text-slate-400">
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto bg-slate-900 relative">
        {children}
      </div>

      {/* Resize Handle */}
      <div
        className="absolute bottom-0 right-0 w-4 h-4 cursor-nwse-resize hover:bg-slate-700 rounded-bl-xl z-50"
        onMouseDown={handleResizeMouseDown}
      />
    </div>
  );
};

export default FloatingWindow;
