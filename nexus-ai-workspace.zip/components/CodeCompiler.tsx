
import React, { useState } from 'react';
import { Play, RotateCcw, Code, Terminal, ExternalLink } from 'lucide-react';

const CodeCompiler: React.FC = () => {
  const [language, setLanguage] = useState<'javascript' | 'python' | 'cpp' | 'html'>('javascript');
  const [code, setCode] = useState(`// Welcome to Nexus Code Lab
function nexusGreet() {
  console.log("Hello from the AI Workspace!");
}

nexusGreet();`);
  const [output, setOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runCode = () => {
    setIsRunning(true);
    setOutput(['> Compiling and running...']);
    
    setTimeout(() => {
      if (language === 'javascript') {
        try {
          // Capture console.log
          const logs: string[] = [];
          const originalLog = console.log;
          console.log = (...args) => logs.push(args.join(' '));
          
          eval(code);
          
          console.log = originalLog;
          setOutput(prev => [...prev, ...logs, '> Execution finished successfully.']);
        } catch (err: any) {
          setOutput(prev => [...prev, `Error: ${err.message}`]);
        }
      } else {
        // Simulation for other languages
        setOutput(prev => [
          ...prev, 
          `[Nexus Sandbox] Executing ${language.toUpperCase()} code...`,
          `Output: Simulated result of ${language} code execution.`,
          `> Process exited with code 0.`
        ]);
      }
      setIsRunning(false);
    }, 800);
  };

  return (
    <div className="flex flex-col h-full bg-[#0d1117]">
      <div className="h-12 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-blue-400">
            <Code size={16} />
            <select 
              className="bg-transparent text-sm font-medium focus:outline-none cursor-pointer"
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
            >
              <option value="javascript">JavaScript</option>
              <option value="html">HTML/CSS</option>
              <option value="python">Python 3</option>
              <option value="cpp">C++ 20</option>
            </select>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setCode('')}
            className="p-1.5 hover:bg-[#30363d] text-slate-400 rounded-md transition-colors"
            title="Clear Code"
          >
            <RotateCcw size={14} />
          </button>
          <button 
            onClick={runCode}
            disabled={isRunning}
            className="bg-green-600 hover:bg-green-500 text-white rounded-md px-3 py-1 flex items-center gap-1.5 text-xs font-bold transition-all"
          >
            {isRunning ? 'Running...' : <><Play size={12} fill="currentColor" /> Run</>}
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Editor Area */}
        <div className="flex-1 border-r border-[#30363d] overflow-hidden flex flex-col">
          <textarea
            className="flex-1 bg-[#0d1117] text-[#c9d1d9] fira-code p-4 text-sm leading-relaxed focus:outline-none resize-none"
            spellCheck={false}
            value={code}
            onChange={(e) => setCode(e.target.value)}
          />
        </div>

        {/* Console Output */}
        <div className="w-full md:w-1/3 bg-[#0d1117] flex flex-col">
          <div className="h-8 bg-[#161b22] border-b border-[#30363d] flex items-center px-4 gap-2 text-[#8b949e]">
            <Terminal size={14} />
            <span className="text-[10px] uppercase font-bold tracking-widest">Console</span>
          </div>
          <div className="flex-1 p-4 fira-code text-xs space-y-1 overflow-auto custom-scrollbar">
            {output.length === 0 && <span className="text-[#484f58]">Output will appear here...</span>}
            {output.map((line, i) => (
              <div key={i} className={line.startsWith('Error') ? 'text-red-400' : line.startsWith('>') ? 'text-[#8b949e]' : 'text-slate-100'}>
                {line}
              </div>
            ))}
          </div>
        </div>
      </div>

      {language === 'html' && (
        <div className="h-1/2 border-t border-[#30363d] bg-white flex flex-col">
          <div className="h-8 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between px-4 text-[#8b949e]">
            <span className="text-[10px] uppercase font-bold tracking-widest">Live Preview</span>
            <ExternalLink size={14} className="cursor-pointer hover:text-white" />
          </div>
          <iframe 
            className="w-full flex-1 border-none"
            srcDoc={code}
            title="Preview"
          />
        </div>
      )}
    </div>
  );
};

export default CodeCompiler;
