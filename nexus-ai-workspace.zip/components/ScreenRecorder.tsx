
import React, { useState, useRef } from 'react';
import { Play, Square, Download, Video, AlertCircle, Info } from 'lucide-react';

const ScreenRecorder: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const getSupportedMimeType = () => {
    const types = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4',
    ];
    for (const type of types) {
      if (MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    }
    return '';
  };

  const startRecording = async () => {
    setError(null);
    setRecordedChunks([]);
    setPreviewUrl(null);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        throw new Error("Screen recording is not supported in this browser or environment.");
      }

      // getDisplayMedia MUST be called directly in the click handler for many browsers
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { 
          displaySurface: "monitor",
          cursor: "always" 
        } as any,
        audio: true
      }).catch(err => {
        if (err.name === 'NotAllowedError' && err.message.includes('permissions policy')) {
          throw new Error("Permission policy 'display-capture' is restricted. Please ensure the app has permission to capture your screen.");
        }
        console.warn("Retrying without audio due to error:", err);
        return navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: false
        });
      });

      streamRef.current = stream;
      
      const mimeType = getSupportedMimeType();
      const options = mimeType ? { mimeType } : undefined;
      
      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: Blob[] = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const finalMimeType = chunks[0]?.type || 'video/webm';
        const blob = new Blob(chunks, { type: finalMimeType });
        setRecordedChunks(chunks);
        setPreviewUrl(URL.createObjectURL(blob));
        setIsRecording(false);
        
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
        }
      };

      // Listen for when the user stops sharing via the browser UI
      stream.getVideoTracks()[0].onended = () => {
        if (mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err: any) {
      console.error("Screen capture error:", err);
      setError(err.message || "Failed to start recording. Ensure you've allowed screen sharing.");
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const downloadRecording = () => {
    if (recordedChunks.length === 0) return;
    const finalMimeType = recordedChunks[0]?.type || 'video/webm';
    const extension = finalMimeType.includes('mp4') ? 'mp4' : 'webm';
    const blob = new Blob(recordedChunks, { type: finalMimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-recording-${Date.now()}.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 p-6 space-y-6">
      <div className="flex flex-col items-center text-center space-y-2">
        <div className={`p-4 rounded-full ${isRecording ? 'bg-red-500/20 text-red-500 animate-pulse' : 'bg-slate-800 text-slate-400'}`}>
          <Video size={32} />
        </div>
        <h2 className="text-xl font-bold text-slate-100">Workspace Recorder</h2>
        <p className="text-slate-400 text-sm max-w-xs">
          Capture your workspace activity. Recordings are processed locally for your privacy.
        </p>
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/50 rounded-lg flex gap-3 text-red-400 text-xs items-center">
          <AlertCircle size={16} className="shrink-0" />
          <p>{error}</p>
        </div>
      )}

      <div className="flex flex-col gap-4">
        {!isRecording ? (
          <button 
            onClick={startRecording}
            className="w-full flex items-center justify-center gap-3 bg-red-600 hover:bg-red-500 text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-red-900/20"
          >
            <Play size={18} fill="currentColor" /> Start Recording
          </button>
        ) : (
          <button 
            onClick={stopRecording}
            className="w-full flex items-center justify-center gap-3 bg-slate-100 hover:bg-white text-slate-900 py-3 rounded-xl font-bold transition-all"
          >
            <Square size={18} fill="currentColor" /> Stop Recording
          </button>
        )}

        {previewUrl && (
          <div className="space-y-3">
            <div className="p-2 bg-slate-800 rounded-lg border border-slate-700">
              <video src={previewUrl} controls className="w-full rounded" />
            </div>
            <button 
              onClick={downloadRecording}
              className="w-full flex items-center justify-center gap-3 bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-900/20"
            >
              <Download size={18} /> Download Recording
            </button>
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 flex gap-3 text-slate-400 text-xs leading-relaxed">
        <Info size={24} className="shrink-0 text-blue-400" />
        <p>Make sure to grant "Display Capture" permissions. If the error persists, check your browser's site settings for screen sharing.</p>
      </div>
    </div>
  );
};

export default ScreenRecorder;
