
import React, { useState, useEffect } from 'react';
import { Save, Trash2, Plus, Search, FileText, ChevronRight } from 'lucide-react';
import { Note } from '../types';

const Notebook: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('nexus-notes');
    return saved ? JSON.parse(saved) : [{
      id: '1',
      title: 'Welcome to Nexus',
      content: 'Welcome to your AI-powered notebook. Start typing here...',
      lastModified: Date.now(),
      category: 'General'
    }];
  });
  const [activeNoteId, setActiveNoteId] = useState<string>(notes[0]?.id || '');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    localStorage.setItem('nexus-notes', JSON.stringify(notes));
  }, [notes]);

  const activeNote = notes.find(n => n.id === activeNoteId) || notes[0];

  const handleNoteChange = (content: string) => {
    setNotes(prev => prev.map(n => n.id === activeNoteId ? { ...n, content, lastModified: Date.now() } : n));
  };

  const handleTitleChange = (title: string) => {
    setNotes(prev => prev.map(n => n.id === activeNoteId ? { ...n, title, lastModified: Date.now() } : n));
  };

  const createNewNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: 'Untitled Note',
      content: '',
      lastModified: Date.now(),
      category: 'General'
    };
    setNotes([newNote, ...notes]);
    setActiveNoteId(newNote.id);
  };

  const deleteNote = (id: string) => {
    if (notes.length === 1) return;
    const filtered = notes.filter(n => n.id !== id);
    setNotes(filtered);
    if (activeNoteId === id) setActiveNoteId(filtered[0].id);
  };

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    n.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex h-full bg-slate-900">
      {/* Sidebar */}
      <div className="w-64 border-r border-slate-700 flex flex-col bg-slate-900/50">
        <div className="p-3 space-y-3">
          <button 
            onClick={createNewNote}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg py-2 transition-all font-medium text-sm shadow-lg shadow-blue-900/20"
          >
            <Plus size={16} /> New Note
          </button>
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-slate-500" size={14} />
            <input 
              type="text" 
              placeholder="Search notes..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
          {filteredNotes.map(note => (
            <button
              key={note.id}
              onClick={() => setActiveNoteId(note.id)}
              className={`w-full group text-left px-3 py-2.5 rounded-lg transition-all flex items-start gap-3 ${
                activeNoteId === note.id ? 'bg-slate-800 text-blue-400' : 'text-slate-400 hover:bg-slate-800/50'
              }`}
            >
              <FileText size={16} className="mt-0.5 shrink-0" />
              <div className="truncate">
                <div className="text-sm font-medium truncate">{note.title}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  {new Date(note.lastModified).toLocaleDateString()}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="p-6 border-b border-slate-700/50 flex justify-between items-center bg-slate-900">
          <input 
            type="text" 
            className="bg-transparent text-2xl font-bold text-slate-100 focus:outline-none w-full mr-4"
            value={activeNote?.title || ''}
            onChange={(e) => handleTitleChange(e.target.value)}
            placeholder="Note Title"
          />
          <div className="flex items-center gap-2">
            <button 
              onClick={() => deleteNote(activeNoteId)}
              className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
              title="Delete Note"
            >
              <Trash2 size={18} />
            </button>
            <button 
              className="p-2 text-slate-500 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
              title="Save (Auto-saved)"
            >
              <Save size={18} />
            </button>
          </div>
        </div>
        
        <div className="flex-1 p-6 overflow-y-auto">
          <textarea
            className="w-full h-full bg-transparent text-slate-300 resize-none focus:outline-none text-lg leading-relaxed placeholder:text-slate-600"
            value={activeNote?.content || ''}
            onChange={(e) => handleNoteChange(e.target.value)}
            placeholder="Write your brilliant thoughts here..."
          />
        </div>
      </div>
    </div>
  );
};

export default Notebook;
