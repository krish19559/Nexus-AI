
export type WindowType = 'notebook' | 'chat' | 'compiler' | 'whiteboard' | 'recorder';

export interface WindowState {
  id: string;
  type: WindowType;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  zIndex: number;
  position: { x: number; y: number };
  size: { width: number; height: number };
}

export interface Note {
  id: string;
  title: string;
  content: string;
  lastModified: number;
  category: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
